# Hierarchical guidance: borrowing strength across weeks and rear types
#
# Wild fish are the target, but most PIT-tagged fish are hatchery. Fitting
# each wild week alone leaves thin weeks with wide, jumpy estimates. A
# hierarchical model shares what wild and hatchery fish have in common and
# keeps what differs:
#
#   logit(psi[r,s]) ~ Normal(mu_strat[g(s)] + rear_psi[r] + beta * spill[s], sigma_psi)
#   mu_strat[g]     ~ Normal(alpha, sigma_strat)
#
#   r = rear type (1 wild, 2 hatchery), s = week, g(s) = the week's stratum
#   rear_psi: fixed offsets, centered to sum to zero (two levels are too few
#             for a random effect; BPA 4.1.4)
#   beta <= 0: spill can only lower guidance
#
# Weeks shrink toward their stratum; strata shrink toward the season average.
# A week with many fish is set by its own fish; a thin week gets pulled in.
# Each rear-week's data come from the six-cell likelihood in 04_six_cell.R.
#
# The script fits two models to the same data and compares wild weekly GE:
#   Model 1: every rear-week on its own (flat prior on each psi)
#   Model 2: hierarchical
#
# Both models share detection, transport, and survival across all rear-weeks;
# only the guidance part differs. Teaching version: those shared pieces are
# held constant over the season.
# All data are simulated. Requires JAGS and the jagsUI package.

library(jagsUI)

set.seed(6)

# 1. Simulate a season ----

R <- 2                                   # 1 = wild, 2 = hatchery
S <- 12                                  # weeks
parent <- rep(1:3, each = 4)             # stratum of each week
n_strat <- 3

alpha <- -2.0
sigma_strat <- 0.5
mu_strat <- rnorm(n_strat, alpha, sigma_strat)
rear_psi <- c(-0.2, 0.2)                 # centered: sums to zero
beta <- -0.6
spill <- runif(S, 0.2, 0.6)
spill_std <- (spill - mean(spill)) / sd(spill)
sigma_psi <- 0.4

logit_psi <- matrix(NA, R, S)
for (r in 1:R) for (s in 1:S) {
  logit_psi[r, s] <- rnorm(1, mu_strat[parent[s]] + rear_psi[r] + beta * spill_std[s], sigma_psi)
}
psi <- plogis(logit_psi)

trans <- 0.60; phi_S <- 0.50; delta <- 0.40; p <- 0.40
phi_B <- plogis(qlogis(phi_S) - delta)

n.tagged <- rbind(round(runif(S, 20, 120)),      # wild: thin
                  round(runif(S, 400, 1500)))    # hatchery: plenty

n <- array(0, c(R, S, 6))
for (r in 1:R) for (s in 1:S) {
  pr <- c(psi[r, s] * (1 - trans) * (1 - phi_B),
          psi[r, s] * (1 - trans) * phi_B,
          (1 - psi[r, s]) * p * (1 - phi_S),
          (1 - psi[r, s]) * p * phi_S,
          (1 - psi[r, s]) * (1 - p) * phi_S,
          psi[r, s] * trans,
          (1 - psi[r, s]) * (1 - p) * (1 - phi_S))
  n[r, s, ] <- rmultinom(1, n.tagged[r, s], pr)[1:6, 1]
}
N_seen <- apply(n, c(1, 2), sum)
print(N_seen)

# 2. The shared observation model ----
# Same six cells as 04_six_cell.R, written once and pasted into both models.

likelihood <- "
trans ~ dbeta(1, 1)
phi_S ~ dbeta(1, 1)
delta ~ dnorm(0, 0.1)
phi_B <- ilogit(logit(phi_S) - delta)
p ~ dbeta(1, 1)
for (r in 1:R) {
   for (s in 1:S) {
      pi_raw[r,s,1] <- psi[r,s] * (1 - trans) * (1 - phi_B)
      pi_raw[r,s,2] <- psi[r,s] * (1 - trans) * phi_B
      pi_raw[r,s,3] <- (1 - psi[r,s]) * p * (1 - phi_S)
      pi_raw[r,s,4] <- (1 - psi[r,s]) * p * phi_S
      pi_raw[r,s,5] <- (1 - psi[r,s]) * (1 - p) * phi_S
      pi_raw[r,s,6] <- psi[r,s] * trans
      p_seen[r,s] <- sum(pi_raw[r,s,1:6])
      for (cc in 1:6) { pi_obs[r,s,cc] <- pi_raw[r,s,cc] / p_seen[r,s] }
      n[r,s,1:6] ~ dmulti(pi_obs[r,s,1:6], N_seen[r,s])
      }
   }
"

# 3. Model 1: every rear-week on its own ----

cat(file = "ge_separate.jags", paste0("
model {
for (r in 1:R) {
   for (s in 1:S) {
      psi[r,s] ~ dbeta(1, 1)
      }
   }
", likelihood, "}
"))

# 4. Model 2: hierarchical ----

cat(file = "ge_hierarchical.jags", paste0("
model {
alpha ~ dnorm(0, 0.1)
sigma_strat ~ dunif(0, 3)
sigma_psi ~ dunif(0, 3)
tau_strat <- pow(sigma_strat, -2)
tau_psi <- pow(sigma_psi, -2)
beta ~ dnorm(0, 0.1) T(, 0)                  # spill can only lower GE

# rear offsets: fixed, centered to sum to zero
for (r in 1:R) { rear_raw[r] ~ dnorm(0, 0.1) }
for (r in 1:R) { rear_psi[r] <- rear_raw[r] - mean(rear_raw[]) }

# strata shrink toward the season average
for (g in 1:n_strat) { mu_strat[g] ~ dnorm(alpha, tau_strat) }

# weeks shrink toward their stratum
for (r in 1:R) {
   for (s in 1:S) {
      logit_psi[r,s] ~ dnorm(mu_strat[parent[s]] + rear_psi[r] + beta * spill_std[s], tau_psi)
      psi[r,s] <- ilogit(logit_psi[r,s])     # convert logit scale to probability scale
      }
   }
", likelihood, "}
"))

jags.data <- list(n = n, N_seen = N_seen, R = R, S = S)
jags.data2 <- c(jags.data, list(parent = parent, n_strat = n_strat, spill_std = spill_std))
inits1 <- function() list(psi = matrix(runif(R * S, 0.05, 0.3), R, S), p = runif(1, 0.2, 0.8),
                          trans = runif(1, 0.2, 0.8), phi_S = runif(1, 0.2, 0.8))
inits2 <- function() list(alpha = rnorm(1, -2, 0.5), beta = -runif(1, 0, 1), p = runif(1, 0.2, 0.8),
                          trans = runif(1, 0.2, 0.8), phi_S = runif(1, 0.2, 0.8),
                          sigma_strat = runif(1, 0.1, 1), sigma_psi = runif(1, 0.1, 1))

fit1 <- jags(jags.data, inits1, c("psi", "p"), "ge_separate.jags",
             n.chains = 3, n.iter = 10000, n.burnin = 5000, n.thin = 5, parallel = TRUE)
fit2 <- jags(jags.data2, inits2, c("psi", "p", "beta", "rear_psi", "sigma_psi"), "ge_hierarchical.jags",
             n.chains = 3, n.iter = 10000, n.burnin = 5000, n.thin = 5, parallel = TRUE)

# 5. Compare wild weekly GE ----
cat("Max Rhat, separate:    ", round(max(unlist(fit1$Rhat), na.rm = TRUE), 3), "\n")
cat("Max Rhat, hierarchical:", round(max(unlist(fit2$Rhat), na.rm = TRUE), 3), "\n")

summ <- function(fit) {
  d <- fit$sims.list$psi[, 1, ]     # draws x weeks, wild only
  list(mean = colMeans(d), lo = apply(d, 2, quantile, 0.025), hi = apply(d, 2, quantile, 0.975))
}
w1 <- summ(fit1); w2 <- summ(fit2)
truth <- psi[1, ]
cat("\nWild weekly GE, mean absolute error:  separate", round(mean(abs(w1$mean - truth)), 3),
    "  hierarchical", round(mean(abs(w2$mean - truth)), 3), "\n")
cat("Wild weekly GE, mean 95% CrI width:   separate", round(mean(w1$hi - w1$lo), 3),
    "  hierarchical", round(mean(w2$hi - w2$lo), 3), "\n")
cat("Spill slope beta: truth", beta, " estimate", round(fit2$mean$beta, 2), "\n")

# 6. Plot ----
par(mar = c(4.5, 4.5, 2, 1), bg = "white")
ymax <- max(w1$hi, w2$hi, truth) * 1.05
plot(1:S - 0.15, w1$mean, ylim = c(0, ymax), xlim = c(0.5, S + 0.5), pch = 16, col = "darkorange",
     las = 1, xlab = "Week", ylab = "Wild guidance efficiency", main = "Wild weekly GE",
     xaxt = "n")
axis(1, at = 1:S)
segments(1:S - 0.15, w1$lo, 1:S - 0.15, w1$hi, col = "darkorange", lwd = 2)
points(1:S + 0.15, w2$mean, pch = 16, col = "steelblue")
segments(1:S + 0.15, w2$lo, 1:S + 0.15, w2$hi, col = "steelblue", lwd = 2)
points(1:S, truth, pch = 4, cex = 1.3, lwd = 2)
text(1:S, ymax, n.tagged[1, ], cex = 0.7, col = "gray40")
legend("topleft", bty = "n", inset = c(0, 0.04),
       legend = c("Truth", "Each week on its own", "Hierarchical", "Numbers: wild fish tagged"),
       pch = c(4, 16, 16, NA), col = c("black", "darkorange", "steelblue", "gray40"))
