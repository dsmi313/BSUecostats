# A logit GLM in JAGS: does spill change guidance?
#
# Each PIT-tagged fish arriving at the dam is either guided into the bypass
# (1) or not (0). That is a Bernoulli trial (BPA 3.5). The logit link keeps
# the guidance probability between 0 and 1 while the linear predictor adds
# covariate effects (BPA 3.2.3).
#
#   guided[i] ~ Bernoulli(psi[i])
#   logit(psi[i]) = b0 + b1 * spill[i]
#
# This version pretends we see every fish's route. Real data don't allow
# that, which is why the later scripts need the multistate cells.
# All data are simulated. Requires JAGS and the jagsUI package.

library(jagsUI)

set.seed(2)

# 1. Simulate fish ----

n.fish <- 400
spill <- runif(n.fish, 0.2, 0.6)                 # Spill share on the day each fish arrived
spill.std <- (spill - mean(spill)) / sd(spill)   # Standardize the covariate

b0 <- -1.0      # Logit guidance at average spill
b1 <- -0.8      # More spill, less guidance
psi <- plogis(b0 + b1 * spill.std)
guided <- rbinom(n.fish, 1, psi)

# 2. JAGS model ----

cat(file = "glm_logit.jags", "
model {
# Priors
b0 ~ dnorm(0, 0.1)
b1 ~ dnorm(0, 0.1)

# Likelihood
for (i in 1:n) {
   guided[i] ~ dbern(psi[i])
   logit(psi[i]) <- b0 + b1 * spill[i]
   }
}
")

jags.data <- list(guided = guided, spill = spill.std, n = n.fish)
inits <- function() list(b0 = rnorm(1), b1 = rnorm(1))
params <- c("b0", "b1")

fit <- jags(jags.data, inits, params, "glm_logit.jags",
            n.chains = 3, n.iter = 6000, n.burnin = 2000, n.thin = 2, parallel = TRUE)

# 3. Results ----
cat("Max Rhat:", round(max(unlist(fit$Rhat), na.rm = TRUE), 3), "\n")
cat("b0: truth", b0, " estimate", round(fit$mean$b0, 2),
    " 95% CrI", round(quantile(fit$sims.list$b0, c(0.025, 0.975)), 2), "\n")
cat("b1: truth", b1, " estimate", round(fit$mean$b1, 2),
    " 95% CrI", round(quantile(fit$sims.list$b1, c(0.025, 0.975)), 2), "\n")

# Adding 1 on the logit scale multiplies the odds by e (about 2.7).
cat("A 1 SD increase in spill multiplies the odds of guidance by",
    round(median(exp(fit$sims.list$b1)), 2), "(posterior median)\n")

# 4. Plot the S-curve ----
# The model is linear on the logit scale and curved on the probability scale.
x <- seq(0.2, 0.6, length.out = 100)
x.std <- (x - mean(spill)) / sd(spill)
pred <- sapply(x.std, function(z) plogis(fit$sims.list$b0 + fit$sims.list$b1 * z))

par(mar = c(4.5, 4.5, 1, 1), bg = "white")
plot(spill, guided + runif(n.fish, -0.03, 0.03), pch = 16, cex = 0.5, col = "gray60",
     las = 1, xlab = "Spill share", ylab = "Guided (1) or not (0)")
polygon(c(x, rev(x)), c(apply(pred, 2, quantile, 0.025), rev(apply(pred, 2, quantile, 0.975))),
        col = adjustcolor("steelblue", 0.25), border = NA)
lines(x, colMeans(pred), col = "steelblue", lwd = 2)
lines(x, plogis(b0 + b1 * x.std), lwd = 2, lty = 2)
legend("topright", bty = "n", legend = c("True guidance", "Estimated, 95% CrI"),
       lty = c(2, 1), lwd = 2, col = c("black", "steelblue"))
