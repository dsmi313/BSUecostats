# Day and night: the eleven-cell model
#
# Guidance differs sharply between day and night. Fish detected at Lower
# Granite (GRJ or GRS) have a passage time, so cells c1, c2, c3, c4, and c6
# each split into a day and a night version. A c5 fish was seen only at GOJ,
# so nobody knows when it passed Lower Granite; c5 stays pooled.
# 5 cells x 2 + 1 = 11 cells.
#
#   a           share of fish passing at night
#   psi_day     daytime guidance
#   psi_night   logit(psi_night) = logit(psi_day) + night_eff
#   psi         weekly guidance, the blend (1 - a) psi_day + a psi_night
#
# Assumption: GRS detection p is the same day and night. The data can't
# test it, because a c5 fish could have passed in either period.
#
# Teaching version: one group, no covariates, and a is estimated from the
# detections. All data are simulated. Requires JAGS and the jagsUI package.

library(jagsUI)

set.seed(5)

# 1. Simulate detection histories ----

n.tagged <- 8000
a <- 0.35
psi_day <- 0.02
night_eff <- 3.0
psi_night <- plogis(qlogis(psi_day) + night_eff)
psi <- (1 - a) * psi_day + a * psi_night
trans <- 0.60
phi_S <- 0.50
delta <- 0.40
phi_B <- plogis(qlogis(phi_S) - delta)
p <- 0.40

cell.prob <- c(
  c1_day   = (1 - a) * psi_day * (1 - trans) * (1 - phi_B),
  c2_day   = (1 - a) * psi_day * (1 - trans) * phi_B,
  c3_day   = (1 - a) * (1 - psi_day) * p * (1 - phi_S),
  c4_day   = (1 - a) * (1 - psi_day) * p * phi_S,
  c6_day   = (1 - a) * psi_day * trans,
  c1_night = a * psi_night * (1 - trans) * (1 - phi_B),
  c2_night = a * psi_night * (1 - trans) * phi_B,
  c3_night = a * (1 - psi_night) * p * (1 - phi_S),
  c4_night = a * (1 - psi_night) * p * phi_S,
  c6_night = a * psi_night * trans,
  c5       = ((1 - a) * (1 - psi_day) + a * (1 - psi_night)) * (1 - p) * phi_S,
  never    = ((1 - a) * (1 - psi_day) + a * (1 - psi_night)) * (1 - p) * (1 - phi_S))
stopifnot(abs(sum(cell.prob) - 1) < 1e-12)

all.fish <- rmultinom(1, n.tagged, cell.prob)[, 1]
n <- all.fish[1:11]
N_seen <- sum(n)
print(all.fish)

# 2. JAGS model ----

cat(file = "eleven_cell.jags", "
model {
# Priors
a ~ dbeta(1, 1)
psi_day ~ dbeta(1, 1)
night_eff ~ dnorm(0, 0.1)
psi_night <- ilogit(logit(psi_day) + night_eff)
psi <- (1 - a) * psi_day + a * psi_night     # weekly GE, the blend
p ~ dbeta(1, 1)                              # same day and night
trans ~ dbeta(1, 1)
phi_S ~ dbeta(1, 1)
delta ~ dnorm(0, 0.1)
phi_B <- ilogit(logit(phi_S) - delta)

# day: cells 1 to 5 (c1 c2 c3 c4 c6); night: 6 to 10; c5 pooled: 11
pi_raw[1] <- (1 - a) * psi_day * (1 - trans) * (1 - phi_B)
pi_raw[2] <- (1 - a) * psi_day * (1 - trans) * phi_B
pi_raw[3] <- (1 - a) * (1 - psi_day) * p * (1 - phi_S)
pi_raw[4] <- (1 - a) * (1 - psi_day) * p * phi_S
pi_raw[5] <- (1 - a) * psi_day * trans
pi_raw[6] <- a * psi_night * (1 - trans) * (1 - phi_B)
pi_raw[7] <- a * psi_night * (1 - trans) * phi_B
pi_raw[8] <- a * (1 - psi_night) * p * (1 - phi_S)
pi_raw[9] <- a * (1 - psi_night) * p * phi_S
pi_raw[10] <- a * psi_night * trans
pi_raw[11] <- ((1 - a) * (1 - psi_day) + a * (1 - psi_night)) * (1 - p) * phi_S

# Condition on being detected
p_seen <- sum(pi_raw[1:11])
for (cc in 1:11) {
   pi_obs[cc] <- pi_raw[cc] / p_seen
   }

# Each detected fish is one roll of an 11-sided die
n[1:11] ~ dmulti(pi_obs[1:11], N_seen)
}
")

jags.data <- list(n = as.vector(n), N_seen = N_seen)
inits <- function() list(a = runif(1, 0.2, 0.5), psi_day = runif(1, 0.01, 0.1), night_eff = runif(1, 0, 2),
                         p = runif(1, 0.2, 0.8), trans = runif(1, 0.2, 0.8),
                         phi_S = runif(1, 0.2, 0.8), delta = rnorm(1, 0, 0.5))
params <- c("a", "psi_day", "psi_night", "psi", "night_eff", "p", "trans", "phi_S", "phi_B")

fit <- jags(jags.data, inits, params, "eleven_cell.jags",
            n.chains = 3, n.iter = 6000, n.burnin = 2000, n.thin = 2, parallel = TRUE)

# 3. Compare to the truth ----
cat("Max Rhat:", round(max(unlist(fit$Rhat), na.rm = TRUE), 3), "\n")
truth <- c(a = a, psi_day = psi_day, psi_night = psi_night, psi = psi, p = p,
           trans = trans, phi_S = phi_S, phi_B = phi_B)
est <- sapply(names(truth), function(k) fit$mean[[k]])
lo <- sapply(names(truth), function(k) quantile(fit$sims.list[[k]], 0.025))
hi <- sapply(names(truth), function(k) quantile(fit$sims.list[[k]], 0.975))
print(round(cbind(truth, estimate = est, lower = lo, upper = hi), 3))

# 4. The pooled answer, by hand ----
# Collapse the 11 cells back to 6 and use the closed-form GE from 04_six_cell.R.
# Weekly GE comes out the same; splitting adds day and night GE and a.
c1 <- n[1] + n[6]; c2 <- n[2] + n[7]; c3 <- n[3] + n[8]
c4 <- n[4] + n[9]; c6 <- n[5] + n[10]; c5 <- n[11]
p.hat <- c4 / (c4 + c5)
ge.pooled <- (c1 + c2 + c6) / (c1 + c2 + c6 + (c3 + c4) / p.hat)
cat("Pooled closed-form weekly GE:", round(ge.pooled, 3),
    "  Eleven-cell blend:", round(fit$mean$psi, 3), "  Truth:", round(psi, 3), "\n")

# 5. Plot ----
par(mar = c(4.5, 6, 1, 1), bg = "white")
k <- length(truth)
plot(est, k:1, xlim = c(0, 1), pch = 16, col = "steelblue", yaxt = "n",
     xlab = "Probability", ylab = "", las = 1)
axis(2, at = k:1, labels = names(truth), las = 1)
segments(lo, k:1, hi, k:1, col = "steelblue", lwd = 2)
points(truth, k:1, pch = 4, cex = 1.4, lwd = 2)
legend("bottomright", bty = "n", legend = c("Truth", "Posterior mean, 95% CrI"),
       pch = c(4, 16), col = c("black", "steelblue"))
