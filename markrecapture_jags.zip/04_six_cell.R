# The six-cell multistate model at Lower Granite Dam
#
# Each PIT-tagged fish reaches Lower Granite and takes one route:
#   guided (psi) into the juvenile bypass, read at GRJ, or
#   not guided (1 - psi), passing the spillway or turbines.
# Guided fish are barged (trans) or returned to the river. Nonguided fish are
# read at the spillway array GRS with probability p. Survivors are read again
# downstream at Little Goose (GOJ): phi_B for bypassed fish, phi_S for the rest.
#
# The route is the hidden state; detections are what we see (BPA Chapter 9).
# Six detectable cells plus one never-detected leaf:
#   c1 GRJ only        psi (1 - trans)(1 - phi_B)
#   c2 GRJ and GOJ     psi (1 - trans) phi_B
#   c3 GRS only        (1 - psi) p (1 - phi_S)
#   c4 GRS and GOJ     (1 - psi) p phi_S
#   c5 GOJ only        (1 - psi)(1 - p) phi_S
#   c6 transported     psi trans
#   never detected     (1 - psi)(1 - p)(1 - phi_S)
#
# Never-detected fish can't be counted, so the likelihood conditions on
# being detected: divide each cell by the chance of being seen at all.
#
# A teaching version, simplified from smoltEASE: one group, no covariates.
# All data are simulated. Requires JAGS and the jagsUI package.

library(jagsUI)

set.seed(4)

# 1. Simulate detection histories ----

n.tagged <- 6000     # Tagged fish reaching Lower Granite (includes never-detected)
psi <- 0.10          # Guidance efficiency, the target
trans <- 0.60        # Share of guided fish that are barged
phi_S <- 0.50        # Reach GOJ after spill or turbine passage
delta <- 0.40        # Bypassed fish do worse, on the logit scale
phi_B <- plogis(qlogis(phi_S) - delta)
p <- 0.40            # GRS detection of nonguided fish

cell.prob <- c(c1 = psi * (1 - trans) * (1 - phi_B),
               c2 = psi * (1 - trans) * phi_B,
               c3 = (1 - psi) * p * (1 - phi_S),
               c4 = (1 - psi) * p * phi_S,
               c5 = (1 - psi) * (1 - p) * phi_S,
               c6 = psi * trans,
               never = (1 - psi) * (1 - p) * (1 - phi_S))
stopifnot(abs(sum(cell.prob) - 1) < 1e-12)

all.fish <- rmultinom(1, n.tagged, cell.prob)[, 1]
n <- all.fish[1:6]          # What PTAGIS shows us
N_seen <- sum(n)
print(all.fish)

# 2. Back-of-envelope estimates ----
# c4 and c5 both skipped the bypass and both reached GOJ. They differ only in
# whether GRS read them, so survival to GOJ cancels (Lincoln-Petersen logic).
p.hat <- n["c4"] / (n["c4"] + n["c5"])
guided <- n["c1"] + n["c2"] + n["c6"]
nonguided.read <- n["c3"] + n["c4"]
ge.hat <- guided / (guided + nonguided.read / p.hat)
cat("Closed form: p-hat =", round(p.hat, 3), " GE =", round(ge.hat, 3), "\n")

# 3. JAGS model ----

cat(file = "six_cell.jags", "
model {
# Priors: flat on the probability scale
psi ~ dbeta(1, 1)
p ~ dbeta(1, 1)
trans ~ dbeta(1, 1)
phi_S ~ dbeta(1, 1)
delta ~ dnorm(0, 0.1)
phi_B <- ilogit(logit(phi_S) - delta)

# Cell probabilities before conditioning
pi_raw[1] <- psi * (1 - trans) * (1 - phi_B)    # c1 GRJ only
pi_raw[2] <- psi * (1 - trans) * phi_B          # c2 GRJ and GOJ
pi_raw[3] <- (1 - psi) * p * (1 - phi_S)        # c3 GRS only
pi_raw[4] <- (1 - psi) * p * phi_S              # c4 GRS and GOJ
pi_raw[5] <- (1 - psi) * (1 - p) * phi_S        # c5 GOJ only
pi_raw[6] <- psi * trans                        # c6 transported

# Condition on being detected: only fish we can see
p_seen <- sum(pi_raw[1:6])
for (cc in 1:6) {
   pi_obs[cc] <- pi_raw[cc] / p_seen
   }

# Each detected fish is one roll of a six-sided die
n[1:6] ~ dmulti(pi_obs[1:6], N_seen)

# Derived: how many tagged fish reached the dam, detected or not
N_total <- N_seen / p_seen
}
")

jags.data <- list(n = as.vector(n), N_seen = N_seen)
inits <- function() list(psi = runif(1, 0.05, 0.5), p = runif(1, 0.2, 0.8),
                         trans = runif(1, 0.2, 0.8), phi_S = runif(1, 0.2, 0.8), delta = rnorm(1, 0, 0.5))
params <- c("psi", "p", "trans", "phi_S", "phi_B", "delta", "N_total")

fit <- jags(jags.data, inits, params, "six_cell.jags",
            n.chains = 3, n.iter = 6000, n.burnin = 2000, n.thin = 2, parallel = TRUE)

# 4. Compare to the truth ----
cat("Max Rhat:", round(max(unlist(fit$Rhat), na.rm = TRUE), 3), "\n")
truth <- c(psi = psi, p = p, trans = trans, phi_S = phi_S, phi_B = phi_B)
est <- sapply(names(truth), function(k) fit$mean[[k]])
lo <- sapply(names(truth), function(k) quantile(fit$sims.list[[k]], 0.025))
hi <- sapply(names(truth), function(k) quantile(fit$sims.list[[k]], 0.975))
print(round(cbind(truth, estimate = est, lower = lo, upper = hi), 3))
cat("Tagged fish reaching the dam: truth", n.tagged, " estimate", round(fit$mean$N_total),
    " 95% CrI", round(quantile(fit$sims.list$N_total, c(0.025, 0.975))), "\n")

# 5. Plot ----
par(mar = c(4.5, 6, 1, 1), bg = "white")
k <- length(truth)
plot(est, k:1, xlim = c(0, 1), pch = 16, col = "steelblue", yaxt = "n",
     xlab = "Probability", ylab = "", las = 1)
axis(2, at = k:1, labels = names(truth), las = 1)
segments(lo, k:1, hi, k:1, col = "steelblue", lwd = 2)
points(truth, k:1, pch = 4, cex = 1.4, lwd = 2)
legend("bottomright", bty = "n", legend = c("Truth", "Posterior mean, 95% CrI"),
       pch = c(4, 16), col = c("black", "steelblue"))
