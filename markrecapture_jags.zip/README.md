# How Many Fish Are There? Mark-Recapture with JAGS

Companion code for the BSU ecological statistics group talk on IDFG mark-recapture, from screw traps to Lower Granite Dam.

Each script simulates data from known values, fits a model in JAGS, and checks the answer against the truth. Start at 01 and work up: each step adds one idea.

**These are teaching examples, not the models IDFG uses for its estimates.** They are simplified so each idea stands on its own. The concepts carry over to the production models.

## Requirements

- R (4.0 or later)
- JAGS 4.x, installed separately from R: https://mcmc-jags.sourceforge.io
- The jagsUI package: `install.packages("jagsUI")`

On Windows, install JAGS before jagsUI. If R can't find JAGS, restart R after installing it.

## Scripts

| Script | Idea | Talk section |
|---|---|---|
| `01_lincoln_petersen.R` | Trap efficiency from marked fish, catch expanded by efficiency, Chapman's correction, and Jensen's inequality. Plain R, no JAGS. | Screw traps; Jensen's inequality |
| `02_bernoulli_logit.R` | A logit GLM in JAGS: each fish is a Bernoulli trial, and spill shifts guidance on the logit scale. | Why model GE on the logit scale |
| `03_state_space_screwtrap.R` | A state-space model for daily screw trap passage. Counts alone estimate N × p; adding efficiency trials recovers N. Days with the trap out are estimated anyway. | Screw traps (extension) |
| `04_six_cell.R` | The multistate model at Lower Granite: six detection cells, conditioning on being detected, and a multinomial likelihood. | Steps 3 and 4 |
| `05_eleven_cell.R` | Day and night: five cells split by passage time, c5 stays pooled, 11 cells in all. | Splitting the cells by day and night |
| `06_hierarchical.R` | Borrowing strength across weeks and rear types. Compares each wild week on its own to the hierarchical fit. | Borrow strength; the hierarchical GE regression |
| `07_recover_truth.R` | A small simulation study: bias and 95% interval coverage over 50 simulated data sets. | Does it recover GE? |

Every script runs top to bottom and prints its results and a plot. Each one writes its JAGS model to a `.jags` file in the working directory. Run times are a few seconds to a few minutes; `03` and `07` are the slowest.

## What to read alongside

Kéry, M., and M. Schaub. 2012. *Bayesian Population Analysis using WinBUGS: A Hierarchical Perspective.* Academic Press. The book's code was written for WinBUGS; the authors also provide a JAGS translation.

- Chapter 3: GLMs, link functions, and the logit (scripts 02, 06)
- Chapter 5: state-space models for counts (script 03)
- Chapter 7: time and group effects, and identifiability (scripts 06, 07)
- Chapter 9: multistate models (scripts 04, 05)

See `USING_THIS_CODE.md` for how to adapt these models to your own data.
