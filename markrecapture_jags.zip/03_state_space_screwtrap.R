# State-space model for daily screw trap abundance
#
# Builds on Kery and Schaub (2012) Bayesian Population Analysis, Chapter 5.
# The process model is the log-scale model from BPA 5.4 (house martins).
# BPA 5.3 and 5.5 make the key point: counts alone estimate an index (N * p),
# not abundance. To get N you need separate information on detection (p).
# At a screw trap, that information is the efficiency trials: marked fish
# released upstream and recaptured. This script shows both halves:
#   Model 1: counts only (BPA Chapter 5 as written). It tracks N * p.
#   Model 2: counts plus efficiency trials. It recovers N.
#
# This is a teaching example, not the model IDFG uses to estimate screw trap
# abundance. The concepts carry over: a process model for true abundance, an
# observation model for what the trap sees, and separate data on detection.
#
# All data are simulated, so we know the truth and can check the answer.
# Requires JAGS (https://mcmc-jags.sourceforge.io) and the jagsUI package.

library(jagsUI)

set.seed(2026)

# 1. Simulate a season of daily passage ----

n.days <- 80

# State process (BPA 5.4): log(N[t+1]) = log(N[t]) + r[t], r[t] ~ Normal(mean.r, sigma.proc)
logN1 <- log(150)        # Fish passing on day 1
mean.r <- 0.01           # Average daily change on the log scale
sigma.proc <- 0.25       # Day-to-day process variation

logN <- numeric(n.days)
logN[1] <- logN1
r <- rnorm(n.days - 1, mean.r, sigma.proc)
for (t in 1:(n.days - 1)) {
  logN[t + 1] <- logN[t] + r[t]
}
N <- round(exp(logN))    # True daily passage (integers)

# Trap efficiency p wanders from day to day on the logit scale.
# Same random walk idea as the state process, one level down.
sigma.p <- 0.15
lp <- numeric(n.days)
lp[1] <- qlogis(0.20)
for (t in 1:(n.days - 1)) {
  lp[t + 1] <- lp[t] + rnorm(1, 0, sigma.p)
}
p <- plogis(lp)

# Observation process, part 1: daily catch. Each passing fish is caught with probability p.
C <- rbinom(n.days, N, p)

# The trap was pulled for debris on days 41 to 45. Those days become NA.
# As in BPA 5.4, JAGS treats NA data as unknowns and estimates N for them anyway.
trap.out <- 41:45
C[trap.out] <- NA

# Observation process, part 2: efficiency trials every other day.
# M fish are marked, released upstream, and R of them are recaptured.
trial.days <- seq(2, n.days, by = 2)
trial.days <- setdiff(trial.days, trap.out)
M <- rep(30, length(trial.days))
R <- rbinom(length(trial.days), M, p[trial.days])

# 2. Model 1: counts only (BPA Chapter 5 as written) ----
# Poisson counts around the latent abundance, with no detection term.
# This is exactly the situation BPA 5.3 warns about: with p < 1,
# the estimated "N" is really N * p.

cat(file = "ssm_counts_only.jags", "
model {
# Priors
logN.est[1] ~ dunif(0, 12)           # Initial log abundance
mean.r ~ dnorm(0, 0.01)              # Mean daily growth rate on the log scale
sigma.proc ~ dunif(0, 2)             # SD of the state process
tau.proc <- pow(sigma.proc, -2)

# State process
for (t in 1:(T - 1)) {
   r[t] ~ dnorm(mean.r, tau.proc)
   logN.est[t + 1] <- logN.est[t] + r[t]
   }

# Observation process
for (t in 1:T) {
   N.est[t] <- exp(logN.est[t])
   C[t] ~ dpois(N.est[t])
   }

N.total <- sum(N.est[])
}
")

jags.data1 <- list(C = C, T = n.days)
inits1 <- function() list(logN.est = c(log(mean(C, na.rm = TRUE)), rep(NA, n.days - 1)),
                          mean.r = 0, sigma.proc = runif(1, 0.1, 0.5))
params1 <- c("N.est", "N.total", "mean.r", "sigma.proc")

ni <- 60000; nb <- 30000; nt <- 30; nc <- 3

fit1 <- jags(jags.data1, inits1, params1, "ssm_counts_only.jags",
             n.chains = nc, n.iter = ni, n.burnin = nb, n.thin = nt, parallel = TRUE)

# 3. Model 2: counts plus efficiency trials ----
# The trials give the model direct information on p, so N and p separate.
# Catch is Poisson(p * N), the standard approximation to binomial thinning
# when N is a continuous latent state.

cat(file = "ssm_with_trials.jags", "
model {
# Priors
logN.est[1] ~ dunif(0, 12)           # Initial log abundance
mean.r ~ dnorm(0, 0.01)              # Mean daily growth rate on the log scale
sigma.proc ~ dunif(0, 2)             # SD of the state process
tau.proc <- pow(sigma.proc, -2)

lp[1] ~ dlogis(0, 1)                 # Same as p[1] ~ Uniform(0, 1)
sigma.p ~ dunif(0, 1)                # SD of the daily change in logit p
tau.p <- pow(sigma.p, -2)

# State process: abundance
for (t in 1:(T - 1)) {
   r[t] ~ dnorm(mean.r, tau.proc)
   logN.est[t + 1] <- logN.est[t] + r[t]
   }

# Trap efficiency: random walk on the logit scale
for (t in 1:(T - 1)) {
   lp[t + 1] ~ dnorm(lp[t], tau.p)
   }

# Observation process, part 1: daily catch
for (t in 1:T) {
   p[t] <- ilogit(lp[t])
   N.est[t] <- exp(logN.est[t])
   C[t] ~ dpois(p[t] * N.est[t])
   }

# Observation process, part 2: efficiency trials
for (k in 1:K) {
   R[k] ~ dbin(p[trial.day[k]], M[k])
   }

N.total <- sum(N.est[])
}
")

jags.data2 <- list(C = C, T = n.days, R = R, M = M, K = length(trial.days), trial.day = trial.days)
inits2 <- function() list(logN.est = c(log(mean(C, na.rm = TRUE) / 0.2), rep(NA, n.days - 1)),
                          mean.r = 0, sigma.proc = runif(1, 0.1, 0.5),
                          sigma.p = runif(1, 0.05, 0.3))
params2 <- c("N.est", "N.total", "p", "mean.r", "sigma.proc", "sigma.p")

fit2 <- jags(jags.data2, inits2, params2, "ssm_with_trials.jags",
             n.chains = nc, n.iter = ni, n.burnin = nb, n.thin = nt, parallel = TRUE)

# 4. Check convergence ----
# Rhat near 1 (below 1.1) for every monitored node.
cat("Model 1 max Rhat:", round(max(unlist(fit1$Rhat), na.rm = TRUE), 3), "\n")
cat("Model 2 max Rhat:", round(max(unlist(fit2$Rhat), na.rm = TRUE), 3), "\n")

# 5. Compare to the truth ----
ci <- function(x) round(quantile(x, c(0.025, 0.975)))
cat("\nTrue season total:           ", sum(N), "\n")
cat("True total of N * p:         ", round(sum(N * p)), "\n")
cat("Model 1 (counts only):       ", round(fit1$mean$N.total),
    " 95% CrI", ci(fit1$sims.list$N.total), "\n")
cat("Model 2 (counts plus trials):", round(fit2$mean$N.total),
    " 95% CrI", ci(fit2$sims.list$N.total), "\n")

# 6. Plot ----
band <- function(fit, col) {
  lo <- apply(fit$sims.list$N.est, 2, quantile, 0.025)
  hi <- apply(fit$sims.list$N.est, 2, quantile, 0.975)
  polygon(c(1:n.days, n.days:1), c(lo, rev(hi)), col = adjustcolor(col, 0.2), border = NA)
  lines(fit$mean$N.est, col = col, lwd = 2)
}

par(mfrow = c(2, 1), mar = c(4.5, 4.5, 2, 1), bg = "white")

# Top: abundance
plot(N, type = "n", ylim = c(0, max(N, fit2$q97.5$N.est) * 1.05), las = 1,
     xlab = "Day of season", ylab = "Fish passing", main = "Daily abundance")
rect(min(trap.out) - 0.5, -1e6, max(trap.out) + 0.5, 1e6, col = "gray92", border = NA)
band(fit1, "darkorange")
band(fit2, "steelblue")
lines(N, col = "black", lwd = 2)
lines(N * p, col = "black", lwd = 1, lty = 2)
points(C, pch = 16, cex = 0.6, col = "gray40")
legend("topleft", bty = "n", cex = 0.8,
       legend = c("True N", "True N * p", "Catch", "Counts only", "Counts plus trials", "Trap out"),
       col = c("black", "black", "gray40", "darkorange", "steelblue", "gray85"),
       lty = c(1, 2, NA, 1, 1, NA), lwd = c(2, 1, NA, 2, 2, NA),
       pch = c(NA, NA, 16, NA, NA, 15), pt.cex = c(1, 1, 0.8, 1, 1, 2))

# Bottom: trap efficiency
p.lo <- apply(fit2$sims.list$p, 2, quantile, 0.025)
p.hi <- apply(fit2$sims.list$p, 2, quantile, 0.975)
plot(p, type = "n", ylim = c(0, max(p.hi, R / M) * 1.05), las = 1,
     xlab = "Day of season", ylab = "Capture probability", main = "Trap efficiency")
polygon(c(1:n.days, n.days:1), c(p.lo, rev(p.hi)), col = adjustcolor("steelblue", 0.2), border = NA)
lines(fit2$mean$p, col = "steelblue", lwd = 2)
lines(p, col = "black", lwd = 2)
points(trial.days, R / M, pch = 16, cex = 0.7, col = "gray40")
legend("topleft", bty = "n", cex = 0.8,
       legend = c("True p", "Estimated p", "Trial R / M"),
       col = c("black", "steelblue", "gray40"), lty = c(1, 1, NA), lwd = c(2, 2, NA), pch = c(NA, NA, 16))
