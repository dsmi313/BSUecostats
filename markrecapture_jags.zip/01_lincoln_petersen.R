# Lincoln-Petersen at a screw trap
#
# One stratum at a rotary screw trap. Some passing fish are caught; a batch of
# caught fish is marked and released upstream, and some of those are caught
# again. The recapture rate estimates trap efficiency, and catch divided by
# efficiency estimates how many fish passed.
#
# Plain R, no JAGS yet. All data are simulated, so we know the truth.
# This is a teaching example, not the estimator IDFG uses.

set.seed(1)

# 1. One stratum ----

N <- 4000      # True number of fish passing the trap
p <- 0.15      # True trap efficiency (chance a passing fish is caught)
M <- 200       # Marked fish released upstream

C <- rbinom(1, N, p)   # Unmarked catch
R <- rbinom(1, M, p)   # Marked fish recaptured

p.hat <- R / M
N.lp <- C / p.hat                                  # Lincoln-Petersen: C * M / R
N.chapman <- (C + 1) * (M + 1) / (R + 1) - 1       # Chapman's bias-corrected version

cat("Catch C =", C, " Recaptures R =", R, "of M =", M, "\n")
cat("Efficiency estimate R / M =", round(p.hat, 3), " (truth", p, ")\n")
cat("Lincoln-Petersen N =", round(N.lp), "\n")
cat("Chapman N          =", round(N.chapman), "\n")
cat("Truth              =", N, "\n")

# 2. Repeat the season many times ----
# How do the two estimators behave across many simulated strata?

n.sims <- 10000
C.sim <- rbinom(n.sims, N, p)
R.sim <- rbinom(n.sims, M, p)
LP.sim <- C.sim * M / R.sim
CH.sim <- (C.sim + 1) * (M + 1) / (R.sim + 1) - 1

cat("\nAcross", n.sims, "simulated strata:\n")
cat("Mean Lincoln-Petersen:", round(mean(LP.sim)), " bias", round(100 * (mean(LP.sim) / N - 1), 1), "%\n")
cat("Mean Chapman:         ", round(mean(CH.sim)), " bias", round(100 * (mean(CH.sim) / N - 1), 1), "%\n")
cat("Middle 95% of Chapman:", round(quantile(CH.sim, c(0.025, 0.975))), "\n")

# 3. Jensen's inequality ----
# Efficiency is uncertain. Expanding by 1 / (average efficiency) is not the
# same as averaging the expansions. Draw efficiency from its posterior
# under a flat prior, Beta(R + 1, M - R + 1), and compare.

p.draws <- rbeta(10000, R + 1, M - R + 1)
cat("\nC / mean(p)  =", round(C / mean(p.draws)), "\n")
cat("mean(C / p)  =", round(mean(C / p.draws)), "\n")
cat("1 / p is convex, so the second is always larger. The gap grows as p gets small.\n")

# 4. Plot ----
par(mfrow = c(1, 2), mar = c(4.5, 4.5, 2, 1), bg = "white")

hist(CH.sim, breaks = 60, col = "gray85", border = "white", las = 1,
     main = "Chapman estimates, 10,000 strata", xlab = "Estimated N")
abline(v = N, lwd = 2)
abline(v = mean(CH.sim), lwd = 2, lty = 2, col = "steelblue")
legend("topright", bty = "n", legend = c("Truth", "Mean estimate"),
       lty = c(1, 2), lwd = 2, col = c("black", "steelblue"))

hist(C / p.draws, breaks = 60, col = "gray85", border = "white", las = 1,
     main = "Expansion C / p over efficiency draws", xlab = "C / p")
abline(v = C / mean(p.draws), lwd = 2, col = "darkorange")
abline(v = mean(C / p.draws), lwd = 2, col = "steelblue")
legend("topright", bty = "n", legend = c("C / mean(p)", "mean(C / p)"),
       lwd = 2, col = c("darkorange", "steelblue"))
