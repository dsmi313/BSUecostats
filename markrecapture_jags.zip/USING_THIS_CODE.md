# Using This Code

The scripts are built around fish passing a dam, but the models are general. If you mark animals and detect them again, count animals with imperfect detection, or estimate a probability that changes over time and between groups, at least one of these scripts fits your problem.

## What each model is good for

**01 Lincoln-Petersen.** Any study where you release a known number of marked animals and count how many come back: trap efficiency trials, mark-resight, creel or survey recapture. Use it to see how sampling noise moves the estimate, and why expanding by 1 / (average detection) underestimates.

**02 Logit GLM.** Any yes/no outcome with covariates: survival to a site, presence at a plot, nest success, a fish taking one route or another. The pattern (Bernoulli trial, logit link, linear predictor) is the building block for everything after it.

**03 State-space model.** Repeated counts over time where detection is below 1: daily trap catches, weekly redd counts, annual surveys. Two lessons carry over:

- Counts alone estimate an index (N × p), not N. To get N you need separate data on detection, such as efficiency trials, double observers, or marked animals.
- Missing days or years can be left as `NA`. The model estimates them from the days around them.

**04 Six-cell multistate model.** Any system where animals take one of several hidden routes or states, and you see them at some detection sites and not others: dam passage, river junctions, breeding states, habitat use. The route is the hidden state; the detection histories are the data.

**05 Eleven-cell model.** What to do when one state splits further (day and night here). Also an example of an assumption you can't test from the data (equal detection day and night), and how to write it down plainly.

**06 Hierarchical model.** Many small groups that are alike but not identical: weeks, sites, streams, years. Thin groups borrow strength from the rest, and well-sampled groups mostly speak for themselves.

**07 Recover the truth.** Any model you write. Before trusting a model on real data, check that it gets the right answer on data where you know the answer.

## Adapting a script to your data

1. **Run the script unchanged first.** Make sure JAGS works and you get the printed results and plot.
2. **Find the data the model needs.** Each JAGS call takes a `jags.data` list. That list is the only thing your real data have to match. For example:
   - `03`: a vector of daily counts `C` (with `NA` for missed days), plus trial releases `M` and recaptures `R` with the day each trial ran.
   - `04`: a vector of six cell counts `n` and their total `N_seen`.
   - `06`: an array `n[group, time, cell]`, plus covariates and a stratum index.
3. **Replace the simulation section with your data**, built to the same shape. Keep the simulation code somewhere: you'll want it for step 5.
4. **Change the model to match your system.** Redraw the detection tree for your sites, write one `pi_raw` line per detectable history, and keep the conditioning lines (`p_seen` and `pi_obs`) as they are.
5. **Simulate from your new model and refit it** (the `07` pattern) before using real data. If it can't recover known values, it won't recover unknown ones.

## Checks to run every time

- **Convergence.** Every Rhat below about 1.1. If not, run longer chains, give better initial values, or simplify the model.
- **Prior vs posterior.** If a parameter's posterior looks just like its prior, the data aren't informing it. In a Bayesian fit an unidentified parameter still gets a posterior (BPA 7.9).
- **Coverage.** Over many simulated data sets, about 95% of 95% intervals should contain the truth.
- **Use the draws, not the summary.** When an answer is a nonlinear function of parameters (1 / p, a product, a ratio), compute it for every posterior draw and then summarize. Plugging in posterior means gives a biased answer (script 01, Jensen's inequality).

## Common extensions

- Covariates on any probability: add terms to its logit linear predictor, as in `02` and `06`.
- Random effects for time or site: replace a fixed parameter with draws from a shared distribution, as in `06`.
- More detection sites: add branches to the tree and cells to the multinomial.
- Combining data sets: add another likelihood line to the same model. The parameters they share are estimated from both.

## Questions

David Smith, Idaho Department of Fish and Game, david.smith@idfg.idaho.gov
