# Does the model recover the truth? A small simulation study
#
# "Truth is known, so we know what to expect from the analysis"
# (Kery and Schaub 2012, Section 1.5). Simulate data from known values, fit
# the model, and ask two questions over many repeats:
#   Bias: on average, does the estimate land on the truth?
#   Coverage: do 95% credible intervals contain the truth about 95% of the time?
#
# This uses the six-cell model from 04_six_cell.R. Each repeat draws its own
# true parameters, so the check isn't tuned to one lucky setting.
# Expect a few minutes. Requires JAGS and the jagsUI package.

library(jagsUI)

set.seed(7)

# 1. The model (same as 04_six_cell.R) ----

cat(file = "six_cell.jags", "
model {
psi ~ dbeta(1, 1)
p ~ dbeta(1, 1)
trans ~ dbeta(1, 1)
phi_S ~ dbeta(1, 1)
delta ~ dnorm(0, 0.1)
phi_B <- ilogit(logit(phi_S) - delta)

pi_raw[1] <- psi * (1 - trans) * (1 - phi_B)
pi_raw[2] <- psi * (1 - trans) * phi_B
pi_raw[3] <- (1 - psi) * p * (1 - phi_S)
pi_raw[4] <- (1 - psi) * p * phi_S
pi_raw[5] <- (1 - psi) * (1 - p) * phi_S
pi_raw[6] <- psi * trans

p_seen <- sum(pi_raw[1:6])
for (cc in 1:6) { pi_obs[cc] <- pi_raw[cc] / p_seen }
n[1:6] ~ dmulti(pi_obs[1:6], N_seen)
}
")

# 2. Simulate, fit, record ----

n.reps <- 50
n.tagged <- 3000
pars <- c("psi", "p", "trans", "phi_S", "phi_B")
results <- data.frame()

for (i in 1:n.reps) {
  truth <- c(psi = runif(1, 0.03, 0.30), p = runif(1, 0.25, 0.60), trans = runif(1, 0.3, 0.8),
             phi_S = runif(1, 0.3, 0.7), delta = runif(1, 0, 0.8))
  truth["phi_B"] <- plogis(qlogis(truth["phi_S"]) - truth["delta"])
  pr <- with(as.list(truth), c(psi * (1 - trans) * (1 - phi_B), psi * (1 - trans) * phi_B,
                                (1 - psi) * p * (1 - phi_S), (1 - psi) * p * phi_S,
                                (1 - psi) * (1 - p) * phi_S, psi * trans,
                                (1 - psi) * (1 - p) * (1 - phi_S)))
  n <- rmultinom(1, n.tagged, pr)[1:6, 1]
  fit <- jags(list(n = n, N_seen = sum(n)), NULL, pars, "six_cell.jags",
              n.chains = 3, n.iter = 4000, n.burnin = 1000, n.thin = 3,
              parallel = FALSE, verbose = FALSE)
  for (k in pars) {
    d <- fit$sims.list[[k]]
    results <- rbind(results, data.frame(rep = i, par = k, truth = truth[k], est = mean(d),
                                         lo = quantile(d, 0.025), hi = quantile(d, 0.975)))
  }
  cat(i, "")
}
cat("\n")

# 3. Summarize ----
results$covered <- results$lo <= results$truth & results$truth <= results$hi
results$error <- results$est - results$truth
summary.table <- do.call(rbind, lapply(split(results, results$par), function(d)
  data.frame(par = d$par[1], mean.error = round(mean(d$error), 4),
             mean.abs.error = round(mean(abs(d$error)), 4),
             coverage.pct = round(100 * mean(d$covered), 1))))
print(summary.table[pars, ], row.names = FALSE)
cat("With", n.reps, "repeats, coverage within about +/-", round(100 * 1.96 * sqrt(0.95 * 0.05 / n.reps)),
    "points of 95% is consistent with binomial noise.\n")

# 4. Plot: estimate vs truth for each parameter ----
par(mfrow = c(2, 3), mar = c(4.5, 4.5, 2, 1), bg = "white")
for (k in pars) {
  d <- results[results$par == k, ]
  lim <- range(d$lo, d$hi, d$truth)
  plot(d$truth, d$est, xlim = lim, ylim = lim, pch = 16, cex = 0.8, las = 1,
       col = ifelse(d$covered, "steelblue", "firebrick"),
       xlab = "Truth", ylab = "Estimate", main = k)
  segments(d$truth, d$lo, d$truth, d$hi, col = ifelse(d$covered, "steelblue", "firebrick"))
  abline(0, 1, lty = 2)
}
plot.new()
legend("center", bty = "n", legend = c("Interval covers truth", "Interval misses truth", "1:1 line"),
       pch = c(16, 16, NA), lty = c(NA, NA, 2), col = c("steelblue", "firebrick", "black"))
